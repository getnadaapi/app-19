const BasRemoteClient = require('bas-remote-node');

async function main() {
  //Set script name, and optionally auth details (login, password)
  const options = {
    scriptName: 'kkk' /* or 'YourScriptName' */,
    login: 'abcabc1',
    password: 'abcabc1'
  };

  //Create client
  const scriptClient = new BasRemoteClient(options);

  //Start application, this may take some time
  await scriptClient.start();

  //Set parameters for function
  const scriptParams = {
    OK: 'OK',
  };

  //Run function and wait for result
  //Following function will return list of strings
  const result = await scriptClient.runFunction('DB' /* or 'YourFunctionName' */, scriptParams);

  //Iterate and output results
  result.forEach(link => {
    console.log(link);
  });

  await scriptClient.close();
}

main();