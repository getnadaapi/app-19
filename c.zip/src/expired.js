const expired = (time, timeout) => Date.now() - time > timeout

module.exports = expired
