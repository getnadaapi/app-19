const { readFile } = require('fs/promises')
const { default: axios } = require('axios')
const parse = require('./parse')
const { debug } = require('./log')
const shuffle = require('./shuffle')
const expired = require('./expired')
const select = require('./select')

class ServerList {
  constructor(config) {
    /**
     * @type {import('../config.js')}
     */
    this.config = config
    this.list = null
    this.listLastUpdated = 0
    this.lastUsed = new Map()
    this.knocks = []
  }

  async select(size) {
    const knocks = await this.getUnusedKnocks()
    const selected = size > knocks.length
      ? await this.startSelection(size - knocks.length)
      : []
    const results = knocks.concat(selected)

    results.forEach(({ host }) => this.lastUsed.set(host, Date.now()))

    return results
  }

  async startSelection(size) {
    const { knockTimeout: timeout } = this.config

    const list = await this.getUnusedList()
    const [ selected, knocked ] = await select(shuffle(list), size, Math.min(30000, timeout))

    this.handleSelection(knocked)

    return selected
  }

  async getUnusedList() {
    const list = await this.getList()
    const used = await this.getUsedHosts()

    return list.filter(({ host }) => !used.includes(host))
  }

  getList() {
    const { listCacheTimeout: expires } = this.config

    // update if expired
    if (expired(this.listLastUpdated, Math.max(60000, expires))) {
      const { list } = this

      this.list = this.getListFromFile()
        .catch(() => this.getListFromRemote())
        .catch(() => list)
      this.listLastUpdated = Date.now()
    }

    return this.list
  }

  getListFromFile() {
    const { listFile: file } = this.config

    return readFile(file, { encoding: 'utf-8' })
      .then(JSON.parse)
      .then(list => list.map(parse))
  }

  getListFromRemote() {
    const { listUrl: url } = this.config

    debug(1)('fetch', url)

    return axios(url)
      .then(({ data }) => data.listSSH)
      .then(list => list.map(parse))
  }

  async getUsedHosts() {
    const { renewAfter: expires } = this.config

    const list = await this.getList()
    const hosts = list.map(({ host }) => host)

    const evictions = [ ...this.lastUsed.entries() ].filter(([ host, time ]) => (
      // non-existent hosts
      !hosts.includes(host)
      // or renewed hosts
      || expired(time, Math.max(60000, expires))
    ))

    if (evictions.length) {
      debug(2)('evict used hosts', evictions)

      evictions.forEach(([ host ]) => this.lastUsed.delete(host))
    }

    return [ ...this.lastUsed.keys() ]
  }

  handleSelection(knocked) {
    knocked.forEach(knocked => knocked.then(([ success, entry ]) => {
      if (success) {
        // only succesful knocks are cached
        this.knocks.push([ Date.now(), entry ])
      } else {
        // servers with unsucessful knocks are marked as used
        this.lastUsed.set(entry.host, Date.now())
      }
    }))

    Promise.all(knocked)
      .then(results => results
        .filter(([ success ]) => !success)
        .map(([ , { host } ]) => host))
      .then(failed => {
        debug(2)('unused knocks', this.knocks.length)
        debug(2)('failed', failed.length, ...failed)
      })
  }

  async getUnusedKnocks() {
    const { knockCacheTimeout: timeout } = this.config

    const used = await this.getUsedHosts()

    debug(4)('used', used.length, 'hosts', ...used)

    this.knocks = this.knocks
      .filter(([ time ]) => !expired(time, timeout))
      .filter(([ , { host } ]) => !used.includes(host))

    return this.knocks.map(([ , entry ]) => entry)
  }
}

module.exports = ServerList
